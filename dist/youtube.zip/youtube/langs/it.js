tinymce.addI18n('it',{
    'YouTube Tooltip'   : "YouTube",
	'YouTube Title'     : "Inserisci un video di Youtube",
	'Youtube URL'       : 'Condividi URL',
	'Youtube ID'        : 'Formato del link per da condividere : http://youtu.be/xxxxxxxx o http://www.youtube.com/watch?v=xxxxxxxx',
	'width'             : 'Larghezza',
	'height'            : 'Altezza',
	'autoplay'          : 'Autoplay',
	'Related video'     : 'Video correlati',
	'HD video'          : 'Guarda in HD',
    'html5'             : 'HTML5',
    'Insert'            : 'Inserisci'
});